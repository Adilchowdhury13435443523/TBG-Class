#TBG Class - Adil Chowdhury
#Jan 19, 2023
#This code will print out and allow the character to move, it also includes a charcter class

import cmd
import os
import sys
import textwrap
import characters

myPlayer = characters.player()

screen_width = 100

def title_screen_selections():
    """This code allows for input from the player and decides to start or quit the game"""
    option = input("> ")
    if option.lower() == ("play"):
        setup_game()
    elif option.lower == ("quit"):
        sys.exit()
    while option.lower() not in ['play', 'help', 'quit']:
        print("please enter valid command")
        option = input("> ")
        if option.lower() == ("play"):
            setup_game()
        elif option.lower == ("quit"):
            sys.exit()


def title_screen():
    """This code makes the title screen for the game"""
    os.system('clear')
    print('########################')
    print('#Welcome to my TBG Game#')
    print('########################')
    print('----------Play----------')
    print('----------Help----------')
    print('----------Quit----------')
    title_screen_selections()

NAME = '' 
DESCRIPTION = 'description'
EXAMINATION = 'examine'
SOLVED = False
UP = 'up', 'north'
DOWN = 'down', 'south'
LEFT = 'left', 'west'
RIGHT = 'right', 'east'

solved_places = {'a1' : False, 'a2' : False, 'a3' : False, 'a4' : False, #dictionary of all rooms
                 'b1' : False, 'b2' : False, 'b3' : False, 'b4' : False,
                 'c1' : False, 'c2' : False, 'c3' : False, 'c4' : False,
                 'd1' : False, 'd2' : False, 'd3' : False, 'd4' : False,
                 }

#Dictionary of all the rooms and descripions
zonemap = {'a1' : {NAME : 'Conservatory', 
                   DESCRIPTION : 'Looks well kept and clean.',
                   EXAMINATION : 'You look closer and find different patterns on the wall.',
                   SOLVED : False,
                   UP : '',
                   DOWN : 'b1',
                   LEFT : '',
                   RIGHT : 'a2'},
           'a2' : {NAME : '', 
                   DESCRIPTION : 'You find nothing - keep moving.',
                   EXAMINATION : 'seriously you find nothing...',
                   SOLVED : False,
                   UP : '',
                   DOWN : 'b2',
                   LEFT : 'a1',
                   RIGHT : 'a3'},
           'a3' : {NAME : '', 
                   DESCRIPTION : 'you find nothing - keep moving.',
                   EXAMINATION : 'nothing...',
                   SOLVED : False,
                   UP : '',
                   DOWN : 'b3',
                   LEFT : 'a2',
                   RIGHT : 'a4'},
           'a4' : {NAME : 'Library', 
                   DESCRIPTION : 'The Library is messy, almost like someone was fighting in here.',
                   EXAMINATION : 'you find a piece of someones shirt... whose could it be?',
                   SOLVED : False,
                   UP : '',
                   DOWN : 'b4',
                   LEFT : 'a3',
                   RIGHT : ''},
           'b1' : {NAME : '', 
                   DESCRIPTION : 'you find nothing - keep moving.',
                   EXAMINATION : 'nothing here.',
                   SOLVED : False,
                   UP : 'a1',
                   DOWN : 'c1',
                   LEFT : '',
                   RIGHT : 'b2'},
           'b2' : {NAME : '', 
                   DESCRIPTION : 'you find nothing - keep moving.',
                   EXAMINATION : 'nothing here.',
                   SOLVED : False,
                   UP : 'a2',
                   DOWN : 'c2',
                   LEFT : 'b1',
                   RIGHT : 'b3'},
           'b3' : {NAME : 'Start', 
                   DESCRIPTION : 'This is where you start - nothing has changed.',
                   EXAMINATION : 'Nothing has changed.',
                   SOLVED : False,
                   UP : 'a3',
                   DOWN : 'c3',
                   LEFT : 'b2',
                   RIGHT : 'b4'},
           'b4' : {NAME : '', 
                   DESCRIPTION : 'you find nothing - keep moving.',
                   EXAMINATION : 'keep moving.',
                   SOLVED : False,
                   UP : 'a4',
                   DOWN : 'c4',
                   LEFT : 'b3',
                   RIGHT : ''},
           'c1' : {NAME : '', 
                   DESCRIPTION : 'you find nothing - keep moving.',
                   EXAMINATION : 'nothing here.',
                   SOLVED : False,
                   UP : 'b1',
                   DOWN : 'd1',
                   LEFT : '',
                   RIGHT : 'c2'},
           'c2' : {NAME : 'study', 
                   DESCRIPTION : 'Study is maintained but seems like someone was here.',
                   EXAMINATION : 'you find a bunch of papers but you can not salvage any writing.',
                   SOLVED : False,
                   UP : 'c2',
                   DOWN : 'd2',
                   LEFT : 'c1',
                   RIGHT : 'c3'},
           'c3' : {NAME : '', 
                   DESCRIPTION : 'nothing here. ',
                   EXAMINATION : 'you find nothing - keep moving.',
                   SOLVED : False,
                   UP : 'b3',
                   DOWN : 'd3',
                   LEFT : 'c2',
                   RIGHT : 'c4'},
           'c4' : {NAME : '', 
                   DESCRIPTION : 'nothing here.',
                   EXAMINATION : 'you find nothing - keep moving.',
                   SOLVED : False,
                   UP : 'b4',
                   DOWN : 'd4',
                   LEFT : 'c3',
                   RIGHT : ''},
           'd1' : {NAME : 'kitchen', 
                   DESCRIPTION : 'Smells really good in here.',
                   EXAMINATION : 'you find dirty footprints that look like they lead to the library.',
                   SOLVED : False,
                   UP : 'c1',
                   DOWN : '',
                   LEFT : '',
                   RIGHT : 'd2'},
           'd2' : {NAME : '', 
                   DESCRIPTION : 'nothing here. ',
                   EXAMINATION : 'you find nothing - keep moving.',
                   SOLVED : False,
                   UP : 'c2',
                   DOWN : '',
                   LEFT : 'd1',
                   RIGHT : 'd3'},
           'd3' : {NAME : '', 
                   DESCRIPTION : 'nothing here',
                   EXAMINATION : 'you find nothing - keep moving',
                   SOLVED : False,
                   UP : 'c3',
                   DOWN : '',
                   LEFT : 'd2',
                   RIGHT : 'd4'},
           'd4' : {NAME : 'Ball Room', 
                   DESCRIPTION : 'There is blood across the walls of the room',
                   EXAMINATION : '"I am coming for you" written on the wall with blood',
                   SOLVED : False,
                   UP : 'c4',
                   DOWN : '',
                   LEFT : 'd3',
                   RIGHT : ''},
         
           }

def print_location():
    """Prints the location on the map of where the player is"""
    print('\n' + ('#' * (4 + len(myPlayer.location))))
    print('# ' + myPlayer.location + ' #')
    print('# ' + zonemap[myPlayer.location][DESCRIPTION] + ' #')
    print('\n' + ('#' * (4 + len(myPlayer.location))))
    
def prompt():
    """Prompts the uses for input and where to move or what they want to do"""
    print("\n" + "===============================")
    print("What would you like to do? ")
    action = input("> ")
    acceptable_actions = ['move', 'go', 'travel', 'interact', 'examine', 'look']
    while action.lower() not in acceptable_actions:
        print("Unknown action, please try again.\n")
        action = input("> ")
    if action.lower() == "quit":
        sys.exit()
    elif action.lower() in ['move', 'go', 'travel']:
        player_move(action.lower())
    elif action.lower() in ['interact', 'examine', 'look']:
        player_examination(action.lower())
        
def player_move(myAction):
    """Handles the movement of the character"""
    ask = "where would you like to move to?\n"
    where = input(ask)
    if where in ['up', 'north']:
        destination = zonemap[myPlayer.location][UP]
        movement_handler(destination)
    elif where in ['down', 'south']:
        destination = zonemap[myPlayer.location][DOWN]
        movement_handler(destination)
    elif where in ['left', 'west']:
        destination = zonemap[myPlayer.location][LEFT]
        movement_handler(destination)    
    elif where in ['right', 'east']:
        destination = zonemap[myPlayer.location][RIGHT]
        movement_handler(destination)
    

def movement_handler(destination):
    """Prints the location of the player"""
    print("\n" + "you have moved to the" + destination)
    myPlayer.location = destination
    print_location()
        
    
def player_examination(action):
    """If the player has already been in the room before it will tell
   them that they have already been there"""
    if zonemap[myPlayer.location][SOLVED]:
        print("you have already been here")
    else:
        print("nothing")


def main_game_loop():
    """While them game is still going, keep prompting the user"""
    while myPlayer.game_over is False:
        prompt()
        
def setup_game():
    """sets up yhr game and keeps the game looping"""
    os.system('clear')
    
    question1 = "what is your name?\n"
    for character in question1:
        sys.stdout.write(character)
        sys.stdout.flush()
    player_name = input("> ")
    myPlayer.name = player_name
    
    myPlayer.hp = 100
        
    question2 = "Welcome "+ player_name + ", to the world of murder mystery, lets see if you can catch the killer!\n"
    for character in question2:
        sys.stdout.write(character)
        sys.stdout.flush()
    player_name = input("> ")
    myPlayer.name = player_name
    
    os.system('clear')
    print("##################")
    print("# Let's start now#")
    print("##################")
    main_game_loop()
        
title_screen() 
        





