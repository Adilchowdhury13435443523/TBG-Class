#TBG Character Class - Adil Chowdhury
#Jan 12, 2023
#This code includes the charcter class for the TBG game

class player:
    def __init__(self):
        self.name = ''
        self.job = ''
        self.hp = 0
        self.location = 'b2'
        self.game_over = False 
myPlayer = player()